/**
 * Dashboard Page - Main overview
 */

import { useTraffic } from '../context/TrafficContext'
import { StatCard, Card, TrafficMap, TrafficChart, CameraCard } from '../components'
import { Car, Users, Bike, Camera } from 'lucide-react'

export default function Dashboard() {
  const { cameras, totals, selectedCamera, setSelectedCamera } = useTraffic()

  // Get top cameras by activity
  const topCameras = [...cameras]
    .filter(c => c.status === 'online')
    .sort((a, b) => (b.vehicles + b.pedestrians) - (a.vehicles + a.pedestrians))
    .slice(0, 4)

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Dashboard</h1>
        <p className="text-gray-400 mt-1">Real-time traffic monitoring for Newcastle upon Tyne</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Vehicles"
          value={totals.vehicles}
          icon={Car}
          color="primary"
        />
        <StatCard
          title="Total Pedestrians"
          value={totals.pedestrians}
          icon={Users}
          color="green"
        />
        <StatCard
          title="Total Cyclists"
          value={totals.cyclists}
          icon={Bike}
          color="amber"
        />
        <StatCard
          title="Active Cameras"
          value={`${totals.activeCameras}/${cameras.length}`}
          icon={Camera}
          color="purple"
        />
      </div>

      {/* Map and Chart Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Map */}
        <Card className="p-5">
          <h3 className="text-lg font-semibold text-white mb-4">Camera Locations</h3>
          <TrafficMap height="350px" />
        </Card>

        {/* Chart */}
        <TrafficChart title="24-Hour Traffic Pattern" height={300} />
      </div>

      {/* Top Cameras */}
      <div>
        <h3 className="text-lg font-semibold text-white mb-4">Busiest Cameras</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {topCameras.map((camera) => (
            <CameraCard
              key={camera.id}
              camera={camera}
              onClick={setSelectedCamera}
              selected={selectedCamera?.id === camera.id}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
